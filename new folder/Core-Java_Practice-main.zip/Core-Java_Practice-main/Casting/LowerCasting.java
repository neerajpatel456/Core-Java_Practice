package Casting;

public class LowerCasting {
	public static void main(String[] args) {
		int n= 100;
		int p= n + (int)20.33;//here 20.0 is double value so firstly we create (int) front of value .. so loses our som datas after . like .33 is not show is output
		System.out.println(p);
	}

}
