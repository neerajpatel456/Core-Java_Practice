package Casting;

public class Upercasting {
	//upercasting double store int value from self
	public static void main(String[] args) {
		double x=10;
		double y= x+18 ;// there 18 is a integer value
		System.out.println(y);
		
		
		
		
	}

}
