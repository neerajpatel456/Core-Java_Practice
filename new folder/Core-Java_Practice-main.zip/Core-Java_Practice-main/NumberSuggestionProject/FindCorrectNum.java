package NumberSuggestionProject;

import java.util.Scanner;

public class FindCorrectNum {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int findme= (int)Math.random()*20;
	    int userName;
		do {
			System.out.println("Guess the number(1-100):");
		
			userName = sc.nextInt();
			if(userName == findme) {
				System.out.println("WOOOHH YOUR NUM IS CORRECT");
			break;
			}
			else if(userName>findme) {
				System.out.println("Your number is to learge");
			}
			else  {
				System.out.println("Your number is to Small");
			}
			
			
		}while(userName >= 0);
		System.out.println("MY number was: "+findme);
		
	}
}
