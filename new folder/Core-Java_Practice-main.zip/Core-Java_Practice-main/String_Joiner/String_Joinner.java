package String_Joiner;
/*
 * String Joiner it a class which are join multiple String and make one Final String .. and also add Separator Between every String
 * Separator like Comma "," "/"  "-" "["  "]"  "|"
 * String joiner Has component 
 * Delimiter= , - /  | thats are include after every Both String
 * Perfix- it is come Before String is Start 
 * Suffix- It's come After String is End 
 */
import java.util.StringJoiner;

public class String_Joinner {
	public static void main(String[] args) {
		StringJoiner sj= new StringJoiner("[","-","]");
		sj.add("Rohit");
		sj.add("Navratna");
		sj.add("Baglota");
		System.out.println(sj);
	}

}
