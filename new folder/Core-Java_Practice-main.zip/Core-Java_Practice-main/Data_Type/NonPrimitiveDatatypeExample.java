package Data_Type;

public class NonPrimitiveDatatypeExample {
	public static void main(String[] args) {
		
		// For String 
		String s="or kaise ho mere bhai";
		System.out.println(s);
		
		int [] num= {90,99,95};
		System.out.println(num.length);
		
	}

}
