package Data_Type;

public class PrimitivedataTypeExample {
   public static void main(String[] args) {
	  
	   // primitive data type;
	   int x=1;
	   float y = 10F;
	   double z= 100D;
	   char c = 'c';
	   boolean yourAge18 =false;
	  System.out.println(x);
	  System.out.println(y);
	   
	 System.out.println(z);
	 System.out.println(c);
	 System.out.println(yourAge18);
   
   }

}
