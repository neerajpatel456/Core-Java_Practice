package Interface_Changes_Java8Fe.interface_java8;

interface  Engine{
	public void start();
	public void breake();
	
	public default void key() {
	  System.out.println("Please switch key");
	}
	
	public static String hello() { //
		System.out.println("Hellow Bhai...");
		return "Hellow Bro..";
	}
	
}
class Car implements Engine{
	
	@Override
	public void start() {
		System.out.println("Engine stert....");
	}
	
	public void breake() {
		System.out.println("Please press breake....");
	}
	
	
}

public class Vehicle {
	public static void main(String[] args) {
		Car c = new Car();
		c.start();
		c.breake();
		c.key();
		Engine.hello();
	}

}
