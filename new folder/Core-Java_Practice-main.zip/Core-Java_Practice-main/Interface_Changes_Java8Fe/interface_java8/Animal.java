package Interface_Changes_Java8Fe.interface_java8;

 interface Dog{
	 public void run();
	 
	 public default void sound() {  // default method 
		 System.out.println("Make A Sweet Sound");
	 }
	public static String hungry() {
		System.out.println("Dhire se Puchh Hilana");
		return "Khilao";
	}
	 
	
 }
 class Animal implements Dog{ 
   @Override
   public void run() {
	   System.out.println("Run RUn Run...");
   } 
 


public static void main(String[] args) {
	Animal ani= new Animal();
	ani.run();
	ani.sound();
    Dog.hungry();// this is static that why print by there Interface name....
	
}
}
