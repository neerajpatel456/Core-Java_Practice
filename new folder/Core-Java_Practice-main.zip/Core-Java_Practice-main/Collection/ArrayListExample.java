package Collection;
import java.util.ArrayList;
//ArrayList  is class.....
//ArrayList is order preserved or Order maintained
//ArrayList is Duplicate allowed
//List is a TYPE SAFE that means it accept same type of data;

public class ArrayListExample {
	public static void main(String[] args) {
		
	
    ArrayList<String> names= new ArrayList<>();
    names.add("Neeraj");
    names.add("Patelji");
    names.add("Patelji");
    names.add("Deepak");
    names.add("Rohit");
    names.add(null);
    names.add("kamal");
    names.add("BHuwan");
    names.add("Sahni");
    names.add("Karan");
    names.add(0, "Start");

//    names.remove(1);// for remove indexing value
//    names.remove("Patelji");// by using object
//    names.removeLast();
//    names.removeFirst();  
    
  //  names.add(00999);//now return type is string so not we addable .. only add string value
    
   
    System.out.println(names);
    System.out.println(names.getFirst());// for get any value using indexing 
    System.out.println(names.get(5));
    
}
	
}
