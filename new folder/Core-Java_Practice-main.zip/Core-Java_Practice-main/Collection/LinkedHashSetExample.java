package Collection;

// not print duplicate value
// Accept null value
// slower than HashSet 
//following Insertion order


import java.util.LinkedHashSet;

public class LinkedHashSetExample {
	public static void main(String[] args) {
		LinkedHashSet<Integer> ls= new LinkedHashSet<>();
		ls.add(null);
		ls.add(11);
		ls.add(12);
		ls.add(15);
		ls.add(13);
		ls.add(10);
		
		
		
		System.out.println(ls);
		
	}

}
