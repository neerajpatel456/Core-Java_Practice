package Collection;


//it not allow null value if we want to store null value give NullPointerException 
//it not print duplicate value;
// it Sortedset Ascending order;
//use Red-Black tree;



import java.util.TreeSet;

public class TreeSetExample {
	public static void main(String[] args) {
		TreeSet<Double> tset= new TreeSet<>();
//		tset.add(null);
		tset.add(10.10);
		tset.add(10.10);
		tset.add(10.);
		tset.add(1111.);
		tset.add(14565644.);
		tset.add(111.22);
		System.out.println(tset);
		
	}

}
