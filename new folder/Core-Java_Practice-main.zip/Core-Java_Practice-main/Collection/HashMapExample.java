package Collection;
import java.util.*;
// not allow duplicate key
// it is KEY-Value pair(key is unique and duplicate value is allow.
// give sorted value.


public class HashMapExample {
	public static void main(String[] args) {
		HashMap<Integer, String> map = new HashMap<>();
		map.put(1, "Java");
		map.put(2, "Spring");
		map.put(1, "Updated"); 
		map.put(3, "Updated"); 
		map.put(4, "Updated"); 
		map.put(5, "Updated"); 
		
		
		
		// overwrite
		System.out.println(map);
		
		}

}
