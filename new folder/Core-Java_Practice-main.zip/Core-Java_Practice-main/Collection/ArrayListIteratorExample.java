package Collection;
import java.util.*;

public class ArrayListIteratorExample {
	public static void main(String[] args) {
		ArrayList<Integer> al= new ArrayList<>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(5);
		System.out.println(al);

		
		Iterator<Integer> str= al.iterator();
		while(str.hasNext()) {
			Integer value= str.next();
			System.out.println(value);
		}
	}

}
