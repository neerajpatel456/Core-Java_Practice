package Collection;
import java.util.*;

 // they have not any Set method they use collection method
 // not allow Duplicate value
 // not follow order....
// Null value allowed hai but  only one
 //HashSet internally HashMap use karta hai.Jitne bhi elements HashSet me store karte ho,HashSet unhe HashMap ke key ke form me store karta hai.Value ke place par internally ek dummy object store hota hai
// in there not allow - primitive data type
public class HashSetCollectionExample {
	
	public static void main(String[] args) {
		HashSet<Double> map= new HashSet<>();
	     map.add(null);
	     map.add(14.14);
	     map.add(13.0);
	     map.add(88.99);
	     map.add(1.11);
	     System.out.println(map);
	     
	
	}
	

}
