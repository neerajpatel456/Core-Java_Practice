package Collection;
import java.util.*;


public class IteratorExampleList {
	public static void main(String[] args) {
		
		List<String> list= new ArrayList<>();
		list.add("Neeraj");
		list.add("Deepak");
		list.add("Rohit");
		list.add("Loveless");
		
		
		System.out.println(list);
		 
		ListIterator<String> it = list.listIterator();//make it Iterator 
		 
		while(it.hasNext()) {
			String value = it.next();
			System.out.println(value);
			if(value.equals("Spring")) {
				it.remove();
			}
		}
		System.out.println(list); //
		
	}

}
