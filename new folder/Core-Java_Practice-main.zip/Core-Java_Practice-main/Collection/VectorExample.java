package Collection;
import java.util.*;
//Allows duplicate elements
//Allows null values
//Maintains insertion order
//Implements List interface
//Old Legacy class Before Java 1.2 (Collection Framework)
//Vector is synchronized (thread-safe)
//Automatically grows its capacity
public interface VectorExample {
	public static void main(String[] args) {
		

		Vector<String> vector = new Vector<>();

        // Adding elements
        vector.add("Neeraj");
        vector.add("Billionaire");
        vector.add("Java");
        vector.add(0, "Mr.");
        System.out.println(vector);

        // Getting element
        System.out.println("Element at index 1: " + vector.get(1));

        // Removing element
        vector.remove("Java");

        // Check size
        System.out.println("Size: " + vector.size());

        // Check if element exists
        System.out.println("Contains 'Neeraj'? " + vector.contains("Neeraj"));

        // Printing full vector
        System.out.println("Vector: " + vector);
        
       
}
}