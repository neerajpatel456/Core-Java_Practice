package Collection;
import java.util.*;
//Older cursor used in Vector and Hashtable.

public class EnumarationExample {
	public static void main(String[] args) {
		Vector<Integer> v = new Vector<>();
		v.add(1);
		v.add(2);
		v.add(3);
		v.add(4);
		v.add(5);
		v.add(6);
		v.add(7);
		v.add(8);
		
		System.out.println(v);
		//Enumeration it just like Iterator
		Enumeration<Integer> en = v.elements();
		
		while(en.hasMoreElements()) { //hashMoreElement() check that element are available or not
		System.out.println(en.nextElement());// nextElement() method  jumb and print next element
		
		
		}
	}

}
