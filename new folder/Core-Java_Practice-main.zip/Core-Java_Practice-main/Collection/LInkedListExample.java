package Collection;
import java.util.LinkedList;
//LinkedList is a use Doubly LinkedList
//it extands list and it is class
//it also order maintaining
// it accept null value
//LinkedList is a dynamic data structure that stores data in nodes.
//Each node has:
//data
//address of next node

public class LInkedListExample {
	public static void main(String[] args) {
		LinkedList llist= new LinkedList();
		
		llist.add(null);
		llist.add(111);
		llist.add(00000111);
		llist.add(123456789);
		llist.add(455441414);
		llist.add(44449494);
		llist.add("bhuwan");
		llist.add(0, "MR Billionaire");
		
		

		
		System.out.println(llist);
		System.out.println(llist.get(0));
	System.out.println(llist.size());// use for check size
	System.out.println(llist.contains("bhuwan"));// use for contains available or not in class
    System.out.println(llist.isEmpty());// check for empty or not
    
	
		
		}

}
