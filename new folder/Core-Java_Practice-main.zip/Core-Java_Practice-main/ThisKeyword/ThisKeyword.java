package ThisKeyword;

public class ThisKeyword {
	int i = 101;
	public static void main(String[] args) {
		
		ThisKeyword n= new ThisKeyword();
		n.Num();
		n.Num1();
		
		
	}
	public void Num1() {
		System.out.println(this);
	System.out.println("neeraj");
	}
	
	public void Num() {
		System.out.println(this.i);// using this key word we can access non static variable.
	}

}
