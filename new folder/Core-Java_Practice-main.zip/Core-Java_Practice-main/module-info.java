/**
 * 
 */
/**
 * 
 */
module core_Java {
}