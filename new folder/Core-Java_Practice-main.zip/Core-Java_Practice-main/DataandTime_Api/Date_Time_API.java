package DataandTime_Api;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;


public class Date_Time_API {
	public static void main(String[] args) {
		LocalDateTime datetime =LocalDateTime.now();
		System.out.println(datetime);
	
		
	

}
}