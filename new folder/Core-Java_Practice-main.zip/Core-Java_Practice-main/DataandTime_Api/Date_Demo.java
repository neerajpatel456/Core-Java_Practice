package DataandTime_Api;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
public class Date_Demo {
	public static void main(String[] args) {
	
	LocalDate date =  LocalDate.now(); //becase LocalDate is Final Class so in their not need to new object; 
	System.out.println(date);
	
	// if you want to Add Years so
	date= date.plusYears(5);
	System.out.println(date);
	
	// if you want to Add Month so
    date= date.plusMonths(1);
    System.out.println(date);
    
     // if you want to Add Days so
    date = date.plusDays(4);
    System.out.println(date);
	// if we want period of time , gap of date and time soo
	Period between= Period.between(LocalDate.parse("2001-09-22"), LocalDate.now());
	System.out.println(between);
}	
}
