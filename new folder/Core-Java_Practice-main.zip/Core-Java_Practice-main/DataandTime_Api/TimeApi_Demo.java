package DataandTime_Api;

import java.time.LocalTime;

public class TimeApi_Demo {
public static void main(String[] args) {
	LocalTime time=LocalTime.now();
	System.out.println(time);
	// if you want to add more time so
	time= time.plusHours(4);
	System.out.println(time);
	
	// if u want o add minuts
	time= time.plusMinutes(15);
	System.out.println(time);
}
}
