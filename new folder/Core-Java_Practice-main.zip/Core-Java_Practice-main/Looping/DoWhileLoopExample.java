package Looping;

public class DoWhileLoopExample {
	
	public static void main(String[] args) {
		int y=1;
		do { 
			System.out.println(y);
			y++;
		}while(y <=101);
			
	}

}
