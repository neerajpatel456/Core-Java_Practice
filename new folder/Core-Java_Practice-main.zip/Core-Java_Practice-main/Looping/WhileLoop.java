package Looping;

public class WhileLoop {
    public static void main(String[] args) {
        int y = 1;   // start from 1
        
        while (y <= 101) {   // run loop 101 times
            System.out.println(y+" =" +" I am Billionaire");
            y++;  // increment
        }
    }
}

