package LembdaExpession_Java8;
/*
 * This is a Without LemdaExpreesion....
 */
interface Demo{
	public void told();	
}
public class LembdaExpession_Example implements Demo {
    @Override
	public void told() {
		System.out.println("Dunia Boltiii Haii..Jee LE Saleee");
	}
    public static void main(String[] args) {
		LembdaExpession_Example lee= new LembdaExpession_Example();
		lee.told();
	}
}
