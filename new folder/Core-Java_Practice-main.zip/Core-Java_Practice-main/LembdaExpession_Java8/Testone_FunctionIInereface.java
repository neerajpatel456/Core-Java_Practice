package LembdaExpession_Java8;
/*
 * this is Functional Interface.. 
 * functional Interface have only one Abstract method... morer thane one so its Show error
 * to Represent one Interface as functional  Interface wed will use @FunctionalInterface
 * functional interface are used to Invoke Lemda expression.(invoke=  to call upon something(to use rule, law, or power ) )
 */
@FunctionalInterface
interface MyInterface{
	public void zero();	
}

public class Testone_FunctionIInereface implements MyInterface {
	@Override
	public void zero() {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
		MyInterface mit = () ->	System.out.println("Zero nhiiiiiii Bhaiyaaaa Hero He Hum");
		mit.zero();
	}
}
