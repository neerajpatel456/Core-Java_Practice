package LembdaExpession_Java8;
/*
 * With Lemda Expression
 * 
 * Lemda expression is used for enable functional programming in java..
 * Lemda expression is a Anonymous function means No Name(Variable name), No Modifier No return type...
 * Functional Programming ---Functional programming means everything will be Represented in the form of Function .. 
 * Function can be exist outside of the class....
 * Function can be passed  as a parameter of Other method and also store into  Reference variable ...
 * 
 */
interface Demo1{
	public void Hero();
}


public class LembdaExpression_Example2  {


	public static void main(String[] args) {
		Demo1 d= ()-> System.out.println("Hero Mera Bhai Haiii or... Samjh ja Bhai");// When we have single line in body then curly braces are Optional
//		Demo1 d1=(a,b)-> System.out.println(a+b+" "+a*b+" "+b/a+" "+a);
		
		d.Hero();
	
	}

}
