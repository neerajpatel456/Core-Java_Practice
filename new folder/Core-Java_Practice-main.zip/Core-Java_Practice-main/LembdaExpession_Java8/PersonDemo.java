package LembdaExpession_Java8;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/*
 * Take a list of Person and Print Person Who age is >=18 using Lambda Expression
 */
class Person {
	String name;
	int age;
	Person(String name,int age){ // this is Constructor
		this.name=name;
		this.age=age;
	}
}
public class PersonDemo{
	public static void main(String[] args) {
		Person p1 = new Person("Neerrjj", 24);
		Person p2= new Person("Deepak",25);
		Person p3= new Person("Pooja", 17);
		Person p4= new Person("Roshan",16);
	    List<Person> persons =  Arrays.asList(p1,p2,p3,p4);// when dataSize is fixed so we use Arrays.asList
		Predicate <Person> predicate= p-> (p.age>=18);
		
          for(Person person:persons){
			if(predicate.test(person)){
				System.out.println(person.name+" "+person.age);
			}
		}
	}
}
