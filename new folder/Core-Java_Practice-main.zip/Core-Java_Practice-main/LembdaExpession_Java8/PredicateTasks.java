package LembdaExpession_Java8;
import java.util.function.*;
/*
 * Q. Declare names in an array and print name which are Starting with "A" using Lamda Expression;
 * String[] names= {"Anushka", "Aditi","Komal","Bawana","Aaryaa"}
 */
public class PredicateTasks {
	public static void main(String[] args) {
		String[] names= {"Anushka", "Aditi","Komal","Bawana","Aaryaa"};
		Predicate<String>p= name -> name.charAt(0)=='A';
		Predicate<String>p1= name -> name.charAt(0)=='B';
		for(String name:names) {
			if(p.test(name)) {
				System.out.println(name);
			}
			if(p1.test(name)) {
				System.out.println(name);
			}
		}
	}


}
