package LembdaExpession_Java8;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

class Employee {
    String name;
    String location;
    String dept;

    Employee(String name, String location, String dept) {
        this.name = name;
        this.location = location;
        this.dept = dept;
    }
}

public class Predicate_Joining {
    public static void main(String[] args) {

        Employee e1 = new Employee("Neeraj", "Bilaspur", "Developer");
        Employee e2 = new Employee("Neeraj", "Banglore", "HR");
        Employee e3 = new Employee("Neeraj", "Bhopal", "Testing");
        Employee e4 = new Employee("Neeraj", "Mumbai", "Business");
        Employee e5 = new Employee("Neeraj", "Noida", "HR");

        List<Employee> ls = Arrays.asList(e1, e2, e3, e4, e5);

        Predicate<Employee> p = e -> e.location.equals("Banglore");
        Predicate<Employee> p2 = e -> e.dept.equals("HR");

        // Joining Predicates
        Predicate<Employee> and = p.and(p2);  // Bangalore + HR // this is a and() method
        Predicate<Employee> or = p.or(p2);    // Bangalore OR HR // this is a or() method


        System.out.println("Employees matching predicate (Bangalore OR HR):");

        for (Employee e : ls) {
            if (or.test(e)) {
                System.out.println(e.name + "  " + e.location + "  " + e.dept);
            }
        }
    }
}

