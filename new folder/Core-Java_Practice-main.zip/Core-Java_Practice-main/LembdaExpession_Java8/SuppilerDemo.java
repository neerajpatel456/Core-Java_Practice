package LembdaExpession_Java8;
/*
 * Supplier functional interface it is predefined Interface...
 * supplier have only one abstract method that is get() method
 * supplier interface will not take any input.. it will only return value
 * Otp Generation
 */
import java.util.function.Supplier;
public class SuppilerDemo {
	public static void main(String[] args) {
		Supplier<String>s =()-> { // lembda expression ()->{    }
			String otp= "Your Otp is: ";
			for(int i=1;i<=5;i++) {
				otp= otp + (int)(Math.random()*10);
				
			}
			return otp;
		};
		System.out.println(s.get());
		System.out.println(s.get());
		System.out.println(s.get());
		System.out.println(s.get());
	}

}
