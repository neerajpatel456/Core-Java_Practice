package LembdaExpession_Java8;
/*
 * Consumer is a predefined Functional programming Interfece..
 * consumer will have only one Abstract method that is Accept(T t) method
 * in hava java 8 froEach() method got introduced forEach(Consumer consumer) method will take Consumer as Parameter
 * Consumer will accept input but it won't return anything...
 */
import java.util.function.Consumer;
public class Consumer_Demo {
	public static void main(String[] args) {
		Consumer<String> c= (name)-> System.out.println( name+",Good evening");
		c.accept("Deepak");
		c.accept("Billionaire");
		c.accept("Neeraj");
		
	}

}
