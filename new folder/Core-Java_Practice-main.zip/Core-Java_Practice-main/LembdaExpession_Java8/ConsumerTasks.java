package LembdaExpession_Java8;
import java.util.function.Consumer;
/*
 * Consumer is a part Function interface...Predefine interface
 * Consumer have only one abstract method that is accept(T t) method..
 * Consumer will only  accept input but won't given any return anything..
 * Also used in forEach() method...
 */
public class ConsumerTasks {
	public static void main(String[] args) {
		Consumer<String> c= name-> System.out.println(name);
		c.accept("Raftaar");
		c.accept("Tejjj");
		c.accept("BHaukaalll ");
		c.accept("Hoshana");
		c.accept("Tijram");
		
	}
}
