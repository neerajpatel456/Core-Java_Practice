package LembdaExpession_Java8;
import java.util.function.Function;
/*
 * Function is Predefine Interface 
 * Function having only one abstract method that is apply(T t)method.
 */
public class Functional_FunctionalInterface {
	public static void main(String[] args) {
		Function<String, Integer>f=(name)-> name.length();
		System.out.println(f.apply("Sahuu"));
		System.out.println(f.apply("Pateljii"));
		System.out.println(f.apply("Sanskari"));
		System.out.println(f.apply("Purush"));
	}

}
