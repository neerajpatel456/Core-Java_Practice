package LembdaExpession_Java8;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
/*
 * It type of funtional interfase
 * Predicate is a condition based  Predefine Funtional interface.. which are return True or Fulse value..
 * predicate have only One method that is called Abstract method... that is test(T t)
 */
public class PredicateDemo1 {
	public static void main(String[] args) {
		Predicate<Integer> p = i-> i>10;
		System.out.println(p.test(10));
		System.out.println(p.test(15));
		System.out.println("___________________________________");
		
		BiPredicate<Integer,Integer> bip=(a,b)-> (a*b) >=20; // BiPredicate is used for store two input
		System.out.println(bip.test(2, 3));
		System.out.println(bip.test(10, 3));
		
	}

}


