package Variables;

public class InstanceVariableMethodCall {
	String n="I am Hero OF my LIfe";
	int x=111;
	
	public static void main(String[] args) {
		InstanceVariableMethodCall ins= new InstanceVariableMethodCall();
		ins.Test();
		
	}
	
	public void Test() {
		System.out.println(n);
		System.out.println(this.x);// if we want to access local variable so we need to use this key
		System.out.println(x);

	}

}
