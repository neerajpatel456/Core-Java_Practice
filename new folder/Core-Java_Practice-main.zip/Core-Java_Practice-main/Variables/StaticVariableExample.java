package Variables;

public class StaticVariableExample {
	static int d= 101; // mandatory to using static keyword it is a always lower case,
	static String e;  // also not mandatory to initialize that.
	static String f="Patel";
	
	public static void main(String[] args) {
	
		
		System.out.println(StaticVariableExample.d);// we can access Static variable with the help of Class name  not needed to create object
		System.out.println(StaticVariableExample.e);
		System.out.println(StaticVariableExample.f);
		System.out.println(StaticVariableExample.d);
		System.out.println(StaticVariableExample.f);
		System.out.println(StaticVariableExample.f);
		System.out.println(StaticVariableExample.d);// several time we print that
		
		
	}
	
	
	

}
