package Variables;

public class InstanceVariableExample {
	int x=10;// create inside of the class and outside if the method 
	int y;// not mandatory to initialize... its giving Output by defult 0 
	public static void main(String[] args) {
		InstanceVariableExample ive= new InstanceVariableExample();  // Object Creation in mandatory with object we conn't access non Static variable
		System.out.println(ive.x);
		System.out.println(ive.y);
		InstanceVariableExample ive2= new InstanceVariableExample();
		System.out.println(ive2.x);
		System.out.println(ive2.x);
		System.out.println(ive2.x);
		System.out.println(ive2.x);// we can print  several time in main method 
		
	}

}
