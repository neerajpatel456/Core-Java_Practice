package Variables;

public class StaticVariWithMethodCall {
	static int x=1000;
	static String n="I am Billionaire";
	
	
	
	public static void main(String[] args) {
		StaticVariWithMethodCall.Test();
		}
		
		
	public static void Test() { // static variable always make static method  otherswise its give error
		System.out.println(StaticVariWithMethodCall.x);
		System.out.println(StaticVariWithMethodCall.n);
		System.out.println(505);
	}




}
