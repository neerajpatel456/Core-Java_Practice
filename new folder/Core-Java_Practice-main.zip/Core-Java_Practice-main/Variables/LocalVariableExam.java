package Variables;

public class LocalVariableExam {
	public static void main(String[] args) {
		int x= 101;
		System.out.println(x);
	}

}
