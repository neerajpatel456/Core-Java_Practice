package Stream_API;

import java.util.Arrays;
import java.util.List;

public class MapToLong_Example {
public static void main(String[] args) {
	List<String> values = Arrays.asList("10","20","30","40");

	long sum = values.stream()
	        .mapToLong(v -> Long.parseLong(v))   // String → long
	        .sum();

	System.out.println(sum);

}
}
