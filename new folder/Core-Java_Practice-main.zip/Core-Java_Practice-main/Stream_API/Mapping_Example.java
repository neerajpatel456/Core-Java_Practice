package Stream_API;
/*
 * Mapping Operations are belong to Intermediate operational Method in the stream API
 * IT is used to  Transfer the Stream element and return transformed element as a new Stream;
 * ex:- Stream map(Function function); 
 */
import java.util.Arrays;
import java.util.List;

public class Mapping_Example {
	public static void main(String[] args) {
		//Approach -1 this is for lowercase latter to Uppercase;
//	List<String>list=Arrays.asList("a b c d e f g h i j k l m n o p q r s t u v w x y z");
//	list.stream().map(l->l.toUpperCase()).forEach(l->  System.out.println(l));
//	Approach -2 this is for Uppercase latter to lowercase
	
	List<String> name= Arrays.asList("YADAV","Bihari","SONU","Sakshi","RAHUL","KARTIK","KARUN","ARJUN");
    name.stream().map(n-> n.toLowerCase()). forEach(n->System.out.println(n));
	
    
	   }
	
	}
