package Stream_API;

import java.util.stream.Stream;

class User{
	 String name;
	 int age;
	 String location; 
 User(String name,int age,String location){
	 this.name=name;
	 this.age=age;
	 this.location=location;
 }
 @Override
 public String toString() {
	return "User [name=" + name + ", age=" + age + ", location=" + location  + "]";
 }
 }
 
public class Filter_Example2 {
	public static void main(String[] args) {
		User u1=new User("BIllionaire",24,"Raigarh");
		User u2=new User("Kountey",23,"Banlore");
		User u3=new User("Arjun",18,"Raipur");
		User u4=new User("Karna",15,"TamilNadu");
		User u5=new User("Abhimanyu",27,"Kerela");
		User u6=new User("Rakesh",30,"Raigarh");
		Stream<User>user=Stream.of(u1,u2,u3,u4,u5,u6);
//		
//		user.filter(u-> u.age>=20 && u.location.startsWith("R")).forEach(u-> System.out.println(u));
		user.filter(u-> u.age<=20 && u.name.startsWith("A")).forEach(u-> System.out.println(u));
	
	}

}
