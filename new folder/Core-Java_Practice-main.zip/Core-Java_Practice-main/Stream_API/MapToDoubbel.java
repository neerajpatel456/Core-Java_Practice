package Stream_API;

import java.util.Arrays;
import java.util.List;

public class MapToDoubbel {
	public static void main(String[] args) {
		
	
	List<String> values = Arrays.asList("5.5","10.5","4.0");

	double total = values.stream()
	        .mapToDouble(v -> Double.parseDouble(v))   // String → double
	        .sum();

	System.out.println(total);

}
}