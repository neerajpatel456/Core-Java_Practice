package Stream_API;

import java.util.List;
import java.util.Arrays;
//import java.util.stream.Stream;

/*
 * filter method is used for filtering the provided data...
 * like in flipkart amazon , youtube have Filter option ..
 * filter() method is part of Intermediate operational method it means it (it perform operation on the stream and Always return a new stream..
 * Flitering means getting required data from original data..
 * filter() method is take a Predicate as a Input and give stream as a output
 
 * Bellow the example of print the the name which are Start with A;
 */


public class FilterMehod {
	public static void main(String[] args) {
		
		List<String> list = Arrays.asList("Patel","Anurag","Asheesh","Abhishekh","Bhawana", "Vijay");
		// Approach-1
//	Stream<String>stream= list.stream();
//	Stream<String>filter=stream.filter(i-> i.startsWith("A"));
//	filter.forEach(i-> System.out.println(i));
	
	// Approach-2 this is a Sort cut of upper have written method
	list.stream().filter(u->u.startsWith("P")).forEach(u->System.out.println(u));
	}
}
