package Stream_API;
import java.util.Arrays;
import java.util.List;

//It is used for Knowing Integer value
public class MaptoInt_example {
			public static void main(String[] args) {

		   List<String> name= Arrays.asList("YADAV","Bihari","SONU","Sakshi","RAHUL","KARTIK","KARUN","ARJUN");
//		   name.stream().mapToInt(n-> n.length()).forEach(n-> System.out.println(n));
		  
		   
}
}
